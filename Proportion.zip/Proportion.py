from kivy.app import App
from kivy.config import Config

from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label

from kivy.uix.gridlayout import GridLayout



Config.set('graphics', 'resizable', '1')
Config.set('graphics', 'width', '225')
Config.set('graphics', 'height', '150')


	
class ProportionApp(App):		
	def build(self):
		
		global textin1
		global textin2
		global textin3
		global textin4
		global label
		
		gl=GridLayout(cols=2,spacing=[10],padding=[10,10,10,10])
		
		textin1=TextInput(text="0")
		gl.add_widget(textin1)
		textin2=TextInput(text="0")
		gl.add_widget(textin2)
		textin3=TextInput(text="0")
		gl.add_widget(textin3)
		textin4=TextInput(text="0")
		gl.add_widget(textin4)
		
		gl.add_widget( Button(text='ok',id='OK',on_press=ProportionApp.push))
		
		label=Label(text="")
		gl.add_widget(label)


		return gl
		
	def push(self):

		gin1=float(textin1.text)
		gin2=float(textin2.text)
		gin3=float(textin3.text)
		gin4=float(textin4.text)
		
		lin1=len(textin1.text)
		lin2=len(textin2.text)
		lin3=len(textin3.text)
		lin4=len(textin4.text)
	
		
		if lin3 >= 2 and lin2 >= 2 and lin1 >= 2:
			a11=gin3 * gin2
			a12=a11 / gin1
			a13=str(a12)
			label.text=a13

		if lin1 >= 2 and lin3 >= 2 and lin4 >= 2:
			a28=gin1 * gin4
			a22=a28 / gin3
			a23=str(a22)
			label.text=a23
		if lin2 >= 2 and lin3 >=2 and lin4 >=2:
			a31=gin2*gin3
			a32=a31/gin4
			a33=str(a32)
			label.text=a33
		if lin1>=2 and lin2>=2 and lin4>=2:
			a41=gin4*gin1
			a42=a41/gin2
			a43=str(a42)
			label.text=a43
	

					
if __name__ == '__main__':	
	ProportionApp().run()